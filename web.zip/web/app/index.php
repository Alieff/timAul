<?php 

echo "slam";

?>