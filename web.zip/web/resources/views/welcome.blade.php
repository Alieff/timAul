<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Inspire Crawler</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../resources/assets/css/templateInspire.css">

<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
</head>
<body style="margin:0">
<nav class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a id="logo" class="navbar-brand" href="#">InspireCrawler</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul id="test" class="nav navbar-nav navbar-right">
                <li class="active"><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">API</a></li> 
                <li><a href="#">Contact</a></li>
                <li><a href="#">FAQ</a></li>
            </ul>
        </div>
    </div>
</nav>
<!-- Image Header-->
<img style="width:100%;padding-top:50px;" src="..\resources\assets\images\landing.jpg" class="img-responsive" alt="Responsive image">
<div style="text-align:center;padding-bottom:50px;height: 350px" class="jumbotron">
<div class="col-lg-8 col-lg-offset-2">
      <h2 id="namaku">INSPIRE CRAWLER</h2>
      <p>
      lorem ipsum dolor sitameet mamet tamet wawkakwa tamet malsaosnma ajwknsalndlksna alsndlknqwilan lknlanslkdn aksdnlkandlnaslkdn anlk nslkadnlkanlkns sndalksndlkasn constectur polodong talamat padasak lololo woqwq lamet tamet sitamet mawalam tollllleemad dadadak lamkadah
      </p>
      <div class="row" style="padding-top: 25px">
      <div class="col-lg-3 col-lg-offset-2 col-md-3 col-md-offset-2 col-xs-3 col-xs-offset-2"><a href="#" class="btn btn-success">Use Our API</a></div>
      <div class="col-lg-3 col-lg-offset-2 col-md-3 col-md-offset-2 col-xs-3 col-xs-offset-2"><a href="#" class="btn btn-success">Find Out More</a></div>
      </div>
</div>
</div>
<div style="width:100%;padding-left:5%;padding-right:5%;padding-top:0px;padding-bottom: 50px" class="container">
    <div class="row">
        <div style="text-align:center" class="col-sm-6 col-md-4 col-lg-4 col-lg-offset-2">
            <h2>Get Quotes by Website</h2>
            <p>Bootstrap is a powerful front-end framework for faster and easier web development. The Bootstrap tutorial section will help you learn the techniques of Bootstrap so that you can create web your own website with much less efforts.</p>
        </div>
        <div style="text-align:center" class="col-sm-6 col-md-4 col-lg-4">
            <h2>Get Quotes by Author</h2>
            <p>The references section outlines all the standard HTML tags and CSS properties along with other useful references such as color names and values, symbols and character entities, web safe fonts, language codes, HTTP messages and much more.</p>
        </div>
    </div>
    
    <div class="row">
        <div class="container col-sm-12">
            
        </div>
    </div>
</div>
<footer class="footer">
        <div class="container">
        <span style="color: #fff" id="copyright" style="height: 100%;line-height: 100%;">
        &copy; Copyright - TimAul 2016
        </span>
        <span style="float: right">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-google-plus"></i></a>
            <a href="#"><i class="fa fa-skype"></i></a>
        </span><!--End container-->
        </div>
</footer><!--End footer 2-->
</body>
</html>                                   
