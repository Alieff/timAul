@extends('layouts.page')
@section('termact')
'active'
@endsection
@section('bodycontent')
	<iframe style='width: 100%;height:85vh;' src='../../InspWeb/apidoc'></iframe>
@endsection