<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <title>RESTful explorer for apiDoc</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php echo Explore::style('bootstrap/css/bootstrap.min.css'); ?>

        <?php echo Explore::style('styles/docs.css'); ?>

        <?php echo Explore::style('styles/inherit.css'); ?>

        <!--[if lt IE 9]>
        <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <?php echo Explore::style('highlightjs/default.min.css'); ?>

    </head>
    <body>
        <header class="navbar navbar-default navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <a href="/" class="navbar-brand">RESTful explorer for apiDoc</a>
                </div>
            </div>
        </header>

        <!-- Begin Body -->
        <div class="container">
            <div class="row">
                <div class="col-md-3" id="leftCol">
                    <?php echo $__env->make(Config::get('explore.sidebar'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <?php echo $__env->make(Config::get('explore.footer'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <?php echo Explore::script('scripts/jquery.min.js'); ?>

        <?php echo Explore::script('highlightjs/highlight.min.js'); ?>

        <?php echo Explore::script('bootstrap/js/bootstrap.min.js'); ?>

        <?php echo Explore::script('scripts/inherit.js'); ?>

    </body>
</html>