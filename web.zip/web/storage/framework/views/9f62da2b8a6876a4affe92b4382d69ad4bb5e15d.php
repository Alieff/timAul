<footer>
    <div class="row">
        <div class="col-lg-12">
            <ul class="list-unstyled">
                <li class="pull-right"><a href="#top">Back to top</a></li>
                <li><a href="http://laravel.in.th" onclick="pageTracker._link(this.href); return false;">Blog</a></li>
                <li><a href="https://facebook.com/jquerytips">Page</a></li>
                <li><a href="https://twitter.com/teepluss">Twitter</a></li>
                <li><a href="https://github.com/teepluss">GitHub</a></li>
            </ul>
            <p>Made by <a href="https://github.com/teepluss" rel="nofollow">Teepluss</a>. Contact him at <a href="mailto:teepluss@gmail.com">teepluss@gmail.com</a>.</p>
            <p>Enhance for <a href="http://apidocjs.com/" rel="nofollow">apiDoc</a>.</p>
        </div>
    </div>
</footer>