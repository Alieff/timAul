<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <title>RESTful explorer for apiDoc</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php echo Explore::style('bootstrap/css/bootstrap.min.css'); ?>

        <?php echo Explore::style('jsonview/jquery.jsonview.css'); ?>

        <style>
            body { background-color: white; color: #666; }
        </style>
    </head>
    <body>
        <div id="json">
            <?php if($dataResponse['httpCode'] != 200 or ! Explore::isJson($dataResponse['response'])): ?> <?php echo $dataResponse['response']; ?> <?php endif; ?>
        </div>


        <?php echo Explore::script('scripts/jquery.min.js'); ?>

        <?php echo Explore::script('highlightjs/highlight.min.js'); ?>

        <?php echo Explore::script('bootstrap/js/bootstrap.min.js'); ?>

        <?php echo Explore::script('jsonview/jquery.jsonview.js'); ?>

        <?php echo Explore::script('scripts/inherit.js'); ?>


        <script>
            var json = <?php echo $dataResponse['response']; ?>


            $(function() {
                $("#json").JSONView(json);
                // with options
                $("#json-collasped").JSONView(json, {collapsed: true});
            });
        </script>
    </body>
</html>