<?php foreach($navigators as $group => $navs): ?>
<div class="panel panel-success">
    <div class="panel-heading">
        <h3 class="panel-title"><?php echo e($group); ?></h3>
    </div>
    <div class="list-group">
        <?php foreach($navs as $i => $v): ?>
        <a href="<?php echo e(URL::route('explore.index.get', array('id' => $i))); ?>" class="list-group-item <?php if($i == $offset): ?> active <?php endif; ?>">
            <?php echo e(array_get($v, 'title', 'Undefined')); ?>

        </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>