<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>API DOCS</title>
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="/assets/docs/api/css/normalize.min.css">
<link rel="stylesheet" href="/assets/docs/api/css/main.css">
<link rel="stylesheet" href="/assets/docs/api/css/prettify.css">
<link rel="stylesheet" href="/assets/docs/api/css/f2m2-grid.css">

<script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="//code.jquery.com/ui/1.10.2/jquery-ui.min.js"></script>
<script src="/assets/docs/api/js/prettify.js"></script>
<script src="/assets/docs/api/js/waypoints.min.js"></script>
<script src="/assets/docs/api/js/highlight.js"></script>
<script src="/assets/docs/api/js/main.js"></script>
