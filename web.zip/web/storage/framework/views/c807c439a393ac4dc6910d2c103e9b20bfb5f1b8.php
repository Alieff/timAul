<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>Loading...</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link href="vendor/bootstrap.min.css" rel="stylesheet" media="screen">
  <link href="vendor/prettify.css" rel="stylesheet" media="screen">
  <link href="css/style.css" rel="stylesheet" media="screen, print">
  <link href="img/favicon.ico" rel="icon" type="image/x-icon">
  <script src="vendor/polyfill.js"></script>
</head>
<body>



<script id="template-project" type="text/x-handlebars-template">
  <div class="pull-left">
    <h1><?php echo e(name); ?></h1>
    <?php echo e(#if description); ?><h2><?php echo e(nl2br description); ?></h2><?php echo e(/if); ?>

  </div>
  <?php echo e(#if template.withCompare); ?>

  <div class="pull-right">
    <div class="btn-group">
      <button id="version" class="btn btn-large dropdown-toggle" data-toggle="dropdown">
        <strong><?php echo e(version); ?></strong> <span class="caret"></span>
      </button>
      <ul id="versions" class="dropdown-menu open-left">
          <li><a id="compareAllWithPredecessor" href="#"><?php echo e(__ "Compare all with predecessor"); ?></a></li>
          <li class="divider"></li>
          <li class="disabled"><a href="#"><?php echo e(__ "show up to version:"); ?></a></li>
  <?php echo e(#each versions); ?>

        <li class="version"><a href="#"><?php echo e(this); ?></a></li>
  <?php echo e(/each); ?>

      </ul>
    </div>
  </div>
  <?php echo e(/if); ?>

  <div class="clearfix"></div>
</script>

<script id="template-header" type="text/x-handlebars-template">
  <?php echo e(#if content); ?>

    <div id="api-_"><?php echo e(content); ?></div>
  <?php echo e(/if); ?>

</script>

<script id="template-footer" type="text/x-handlebars-template">
  <?php echo e(#if content); ?>

    <div id="api-_footer"><?php echo e(content); ?></div>
  <?php echo e(/if); ?>

</script>

<script id="template-generator" type="text/x-handlebars-template">
  <?php echo e(#if template.withGenerator); ?>

    <?php echo e(#if generator); ?>

      <div class="content">
        <?php echo e(__ "Generated with"); ?> <a href="<?php echo e(generator.url); ?>"><?php echo e(generator.name); ?></a> <?php echo e(generator.version); ?> - <?php echo e(generator.time); ?>

      </div>
    <?php echo e(/if); ?>

  <?php echo e(/if); ?>

</script>

<script id="template-sections" type="text/x-handlebars-template">
  <section id="api-<?php echo e(group); ?>">
    <h1><?php echo e(underscoreToSpace title); ?></h1>
    <?php echo e(#if description); ?>

      <p><?php echo e(nl2br description); ?></p>
    <?php echo e(/if); ?>

    <?php echo e(#each articles); ?>

      <div id="api-<?php echo e(group); ?>-<?php echo e(name); ?>">
        <?php echo e(article); ?>

      </div>
    <?php echo e(/each); ?>

  </section>
</script>

<script id="template-article" type="text/x-handlebars-template">
  <article id="api-<?php echo e(article.group); ?>-<?php echo e(article.name); ?>-<?php echo e(article.version); ?>" <?php echo e(#if hidden); ?>class="hide"<?php echo e(/if); ?> data-group="<?php echo e(article.group); ?>" data-name="<?php echo e(article.name); ?>" data-version="<?php echo e(article.version); ?>">
    <div class="pull-left">
      <h1><?php echo e(article.groupTitle); ?><?php echo e(#if article.title); ?> - <?php echo e(article.title); ?><?php echo e(/if); ?></h1>
    </div>
    <?php echo e(#if template.withCompare); ?>

    <div class="pull-right">
      <div class="btn-group">
        <button class="version btn dropdown-toggle" data-toggle="dropdown">
          <strong><?php echo e(article.version); ?></strong> <span class="caret"></span>
        </button>
        <ul class="versions dropdown-menu open-left">
          <li class="disabled"><a href="#"><?php echo e(__ "compare changes to:"); ?></a></li>
  <?php echo e(#each versions); ?>

          <li class="version"><a href="#"><?php echo e(this); ?></a></li>
  <?php echo e(/each); ?>

        </ul>
      </div>
    </div>
    <?php echo e(/if); ?>

    <div class="clearfix"></div>

    <?php echo e(#if article.description); ?>

      <p><?php echo e(nl2br article.description); ?></p>
    <?php echo e(/if); ?>


    <pre class="prettyprint language-html" data-type="<?php echo e(toLowerCase article.type); ?>"><code><?php echo e(article.url); ?></code></pre>

    <?php echo e(#if article.permission); ?>

      <p>
        <?php echo e(__ "Permission:"); ?>

        <?php echo e(#each article.permission); ?>

          <?php echo e(name); ?>

          <?php echo e(#if title); ?>

            &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br description); ?>" title="" data-original-title="<?php echo e(title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
            <?php echo e(#unless @last); ?>, <?php echo e(/unless); ?>

          <?php echo e(/if); ?>

        <?php echo e(/each); ?>

      </p>
    <?php echo e(/if); ?>


    <?php echo e(#if_gt article.examples.length compare=0); ?>

      <ul class="nav nav-tabs nav-tabs-examples">
        <?php echo e(#each article.examples); ?>

          <li<?php echo e(#if_eq @index  compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
            <a href="#examples-<?php echo e(../id); ?>-<?php echo e(@index); ?>"><?php echo e(title); ?></a>
          </li>
        <?php echo e(/each); ?>

      </ul>

      <div class="tab-content">
      <?php echo e(#each article.examples); ?>

        <div class="tab-pane<?php echo e(#if_eq @index  compare=0); ?> active<?php echo e(/if_eq); ?>" id="examples-<?php echo e(../id); ?>-<?php echo e(@index); ?>">
          <pre class="prettyprint language-<?php echo e(type); ?>" data-type="<?php echo e(type); ?>"><code><?php echo e(content); ?></code></pre>
        </div>
      <?php echo e(/each); ?>

      </div>
    <?php echo e(/if_gt); ?>


    <?php echo e(subTemplate "article-param-block" params=article.header _hasType=_hasTypeInHeaderFields section="header"); ?>

    <?php echo e(subTemplate "article-param-block" params=article.parameter _hasType=_hasTypeInParameterFields section="parameter"); ?>

    <?php echo e(subTemplate "article-param-block" params=article.success _hasType=_hasTypeInSuccessFields section="success"); ?>

    <?php echo e(subTemplate "article-param-block" params=article.error _col1="Name" _hasType=_hasTypeInErrorFields section="error"); ?>


    <?php echo e(subTemplate "article-sample-request" article=article id=id); ?>


  </article>
</script>

<script id="template-article-param-block" type="text/x-handlebars-template">
  <?php echo e(#if params); ?>

    <?php echo e(#each params.fields); ?>

      <h2><?php echo e(__ @key); ?></h2>
      <table>
        <thead>
          <tr>
          <th style="width: 30%"><?php echo e(#if ../../_col1); ?><?php echo e(__ ../../_col1); ?><?php echo e(else); ?><?php echo e(__ "Field"); ?><?php echo e(/if); ?></th>
            <?php echo e(#if ../../_hasType); ?><th style="width: 10%"><?php echo e(__ "Type"); ?></th><?php echo e(/if); ?>

            <th style="width: <?php echo e(#if ../../_hasType); ?>60%<?php echo e(else); ?>70%<?php echo e(/if); ?>"><?php echo e(__ "Description"); ?></th>
          </tr>
        </thead>
        <tbody>
      <?php echo e(#each this); ?>

          <tr>
            <td class="code"><?php echo e(splitFill field "." "&nbsp;&nbsp;"); ?><?php echo e(#if optional); ?> <span class="label label-optional"><?php echo e(__ "optional"); ?></span><?php echo e(/if); ?></td>
            <?php echo e(#if ../../_hasType); ?>

              <td>
                <?php echo e(type); ?>

              </td>
            <?php echo e(/if); ?>

            <td>
            <?php echo e(nl2br description); ?>

            <?php echo e(#if defaultValue); ?><p class="default-value"><?php echo e(__ "Default value:"); ?> <code><?php echo e(defaultValue); ?></code></p><?php echo e(/if); ?>

            <?php echo e(#if size); ?><p class="type-size"><?php echo e(__ "Size range:"); ?> <code><?php echo e(size); ?></code></p><?php echo e(/if); ?>

            <?php echo e(#if allowedValues); ?><p class="type-size"><?php echo e(__ "Allowed values:"); ?>

              <?php echo e(#each allowedValues); ?>

                <code><?php echo e(this); ?></code><?php echo e(#unless @last); ?>, <?php echo e(/unless); ?>

              <?php echo e(/each); ?>

              </p>
            <?php echo e(/if); ?>

            </td>
          </tr>
      <?php echo e(/each); ?>

        </tbody>
      </table>
    <?php echo e(/each); ?>


    <?php echo e(#if_gt params.examples.length compare=0); ?>

      <ul class="nav nav-tabs nav-tabs-examples">
        <?php echo e(#each params.examples); ?>

          <li<?php echo e(#if_eq @index  compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
            <a href="#<?php echo e(../section); ?>-examples-<?php echo e(../id); ?>-<?php echo e(@index); ?>"><?php echo e(title); ?></a>
          </li>
        <?php echo e(/each); ?>

      </ul>

      <div class="tab-content">
      <?php echo e(#each params.examples); ?>

        <div class="tab-pane<?php echo e(#if_eq @index  compare=0); ?> active<?php echo e(/if_eq); ?>" id="<?php echo e(../section); ?>-examples-<?php echo e(../id); ?>-<?php echo e(@index); ?>">
        <pre class="prettyprint language-<?php echo e(type); ?>" data-type="<?php echo e(type); ?>"><code><?php echo e(reformat content type); ?></code></pre>
        </div>
      <?php echo e(/each); ?>

      </div>
    <?php echo e(/if_gt); ?>


  <?php echo e(/if); ?>

</script>

<script id="template-article-sample-request" type="text/x-handlebars-template">
    <?php echo e(#if article.sampleRequest); ?>

      <h2><?php echo e(__ "Send a Sample Request"); ?></h2>
      <form class="form-horizontal">
        <fieldset>
          <div class="control-group">
            <div class="controls">
              <div class="input-prepend">>
                <span class="add-on"><?php echo e(__ "url"); ?></span>
                <input type="text" class="input-xxlarge sample-request-url" value="<?php echo e(article.sampleRequest.0.url); ?>" />
              </div>
            </div>
          </div>

      <?php echo e(#if article.header); ?>

        <?php echo e(#if article.header.fields); ?>

          <h3><?php echo e(__ "Headers"); ?></h3>
          <?php echo e(#each article.header.fields); ?>

            <h4><input type="radio" data-sample-request-header-group-id="sample-request-header-<?php echo e(@index); ?>" name="<?php echo e(../id); ?>-sample-request-header" value="<?php echo e(@index); ?>" class="sample-request-header sample-request-switch"<?php echo e(#if_eq @index  compare=0); ?> checked<?php echo e(/if_eq); ?>> <?php echo e(@key); ?></h4>
            <div class="<?php echo e(../id); ?>-sample-request-header-fields<?php echo e(#if_gt @index  compare=0); ?> hide<?php echo e(/if_gt); ?>">
              <?php echo e(#each this); ?>

              <div class="control-group">
                <label class="control-label" for="sample-request-header-field-<?php echo e(field); ?>"><?php echo e(field); ?></label>
                <div class="controls">
                  <div class="input-append">>
                    <input type="text" placeholder="<?php echo e(field); ?>" class="input-xxlarge sample-request-header" data-sample-request-header-name="<?php echo e(field); ?>" data-sample-request-header-group="sample-request-header-<?php echo e(@../index); ?>">
                    <span class="add-on"><?php echo e(type); ?></span>
                  </div>
                </div>
              </div>
              <?php echo e(/each); ?>

            </div>
          <?php echo e(/each); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>


      <?php echo e(#if article.parameter); ?>

        <?php echo e(#if article.parameter.fields); ?>

          <h3><?php echo e(__ "Parameters"); ?></h3>
          <?php echo e(#each article.parameter.fields); ?>

            <h4><input type="radio" data-sample-request-param-group-id="sample-request-param-<?php echo e(@index); ?>"  name="<?php echo e(../id); ?>-sample-request-param" value="<?php echo e(@index); ?>" class="sample-request-param sample-request-switch"<?php echo e(#if_eq @index  compare=0); ?> checked<?php echo e(/if_eq); ?>> <?php echo e(@key); ?></h4>
            <div class="<?php echo e(../id); ?>-sample-request-param-fields<?php echo e(#if_gt @index  compare=0); ?> hide<?php echo e(/if_gt); ?>">
              <?php echo e(#each this); ?>

              <div class="control-group">
                <label class="control-label" for="sample-request-param-field-<?php echo e(field); ?>"><?php echo e(field); ?></label>
                <div class="controls">
                  <div class="input-append">>
                    <input type="text" placeholder="<?php echo e(field); ?>" class="input-xxlarge sample-request-param" data-sample-request-param-name="<?php echo e(field); ?>" data-sample-request-param-group="sample-request-param-<?php echo e(@../index); ?>">
                    <span class="add-on"><?php echo e(type); ?></span>
                  </div>
                </div>
              </div>
              <?php echo e(/each); ?>

            </div>
          <?php echo e(/each); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>


          <div class="control-group">
            <div class="controls">
              <button class="btn btn-default sample-request-send" data-sample-request-type="<?php echo e(article.type); ?>"><?php echo e(__ "Send"); ?></button>
            </div>
          </div>

          <div class="sample-request-response" style="display: none;">
            <h3>
              <?php echo e(__ "Response"); ?>

              <button class="btn btn-small btn-default pull-right sample-request-clear">X</button>
            </h3>
            <pre class="prettyprint language-json" data-type="json"><code class="sample-request-response-json"></code></pre>
          </div>

        </fieldset>
      </form>
    <?php echo e(/if); ?>

</script>

<script id="template-compare-article" type="text/x-handlebars-template">
  <article id="api-<?php echo e(article.group); ?>-<?php echo e(article.name); ?>-<?php echo e(article.version); ?>" <?php echo e(#if hidden); ?>class="hide"<?php echo e(/if); ?> data-group="<?php echo e(article.group); ?>" data-name="<?php echo e(article.name); ?>" data-version="<?php echo e(article.version); ?>" data-compare-version="<?php echo e(compare.version); ?>">
    <div class="pull-left">
      <h1><?php echo e(underscoreToSpace article.group); ?> - <?php echo e(showDiff article.title compare.title); ?></h1>
    </div>

    <div class="pull-right">
      <div class="btn-group">
        <button class="btn btn-success" disabled>
          <strong><?php echo e(article.version); ?></strong> <?php echo e(__ "compared to"); ?>

        </button>
        <button class="version btn btn-danger dropdown-toggle" data-toggle="dropdown">
          <strong><?php echo e(compare.version); ?></strong> <span class="caret"></span>
        </button>
        <ul class="versions dropdown-menu open-left">
          <li class="disabled"><a href="#"><?php echo e(__ "compare changes to:"); ?></a></li>
          <li class="divider"></li>
  <?php echo e(#each versions); ?>

          <li class="version"><a href="#"><?php echo e(this); ?></a></li>
  <?php echo e(/each); ?>

        </ul>
      </div>
    </div>
    <div class="clearfix"></div>

    <?php echo e(#if article.description); ?>

      <p><?php echo e(showDiff article.description compare.description "nl2br"); ?></p>
    <?php echo e(else); ?>

      <?php echo e(#if compare.description); ?>

      <p><?php echo e(showDiff "" compare.description "nl2br"); ?></p>
      <?php echo e(/if); ?>

    <?php echo e(/if); ?>


    <pre class="prettyprint language-html" data-type="<?php echo e(toLowerCase article.type); ?>"><code><?php echo e(showDiff article.url compare.url); ?></code></pre>

    <?php echo e(subTemplate "article-compare-permission" article=article compare=compare); ?>


    <ul class="nav nav-tabs nav-tabs-examples">
    <?php echo e(#each_compare_title article.examples compare.examples); ?>


      <?php echo e(#if typeSame); ?>

        <li<?php echo e(#if_eq index compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
          <a href="#compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>"><?php echo e(showDiff source.title compare.title); ?></a>
        </li>
      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <li<?php echo e(#if_eq index compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
          <a href="#compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>"><ins><?php echo e(source.title); ?></ins></a>
        </li>
      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <li<?php echo e(#if_eq index compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
          <a href="#compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>"><del><?php echo e(compare.title); ?></del></a>
        </li>
      <?php echo e(/if); ?>


    <?php echo e(/each_compare_title); ?>

    </ul>

    <div class="tab-content">
    <?php echo e(#each_compare_title article.examples compare.examples); ?>


      <?php echo e(#if typeSame); ?>

        <div class="tab-pane<?php echo e(#if_eq index compare=0); ?> active<?php echo e(/if_eq); ?>" id="compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>">
          <pre class="prettyprint language-<?php echo e(source.type); ?>" data-type="<?php echo e(source.type); ?>"><code><?php echo e(showDiff source.content compare.content); ?></code></pre>
        </div>
      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <div class="tab-pane<?php echo e(#if_eq index compare=0); ?> active<?php echo e(/if_eq); ?>" id="compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>">
          <pre class="prettyprint language-<?php echo e(source.type); ?>" data-type="<?php echo e(source.type); ?>"><code><?php echo e(source.content); ?></code></pre>
        </div>
      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <div class="tab-pane<?php echo e(#if_eq index compare=0); ?> active<?php echo e(/if_eq); ?>" id="compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>">
          <pre class="prettyprint language-<?php echo e(source.type); ?>" data-type="<?php echo e(compare.type); ?>"><code><?php echo e(compare.content); ?></code></pre>
        </div>
      <?php echo e(/if); ?>


    <?php echo e(/each_compare_title); ?>

    </div>

    <?php echo e(subTemplate "article-compare-param-block" source=article.parameter compare=compare.parameter _hasType=_hasTypeInParameterFields section="parameter"); ?>

    <?php echo e(subTemplate "article-compare-param-block" source=article.success compare=compare.success _hasType=_hasTypeInSuccessFields section="success"); ?>

    <?php echo e(subTemplate "article-compare-param-block" source=article.error compare=compare.error _col1="Name" _hasType=_hasTypeInErrorFields section="error"); ?>


    <?php echo e(subTemplate "article-sample-request" article=article id=id); ?>


  </article>
</script>

<script id="template-article-compare-permission" type="text/x-handlebars-template">
  <?php echo e(#each_compare_list_field article.permission compare.permission field="name"); ?>

    <?php echo e(#if source); ?>

      <?php echo e(#if typeSame); ?>

        <?php echo e(source.name); ?>

        <?php echo e(#if source.title); ?>

          &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br source.description); ?>" title="" data-original-title="<?php echo e(source.title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
          <?php echo e(#unless _last); ?>, <?php echo e(/unless); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <ins><?php echo e(source.name); ?></ins>
        <?php echo e(#if source.title); ?>

          &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br source.description); ?>" title="" data-original-title="<?php echo e(source.title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
          <?php echo e(#unless _last); ?>, <?php echo e(/unless); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <del><?php echo e(source.name); ?></del>
        <?php echo e(#if source.title); ?>

          &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br source.description); ?>" title="" data-original-title="<?php echo e(source.title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
          <?php echo e(#unless _last); ?>, <?php echo e(/unless); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>

    <?php echo e(else); ?>

      <?php echo e(#if typeSame); ?>

        <?php echo e(compare.name); ?>

        <?php echo e(#if compare.title); ?>

          &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br compare.description); ?>" title="" data-original-title="<?php echo e(compare.title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
          <?php echo e(#unless _last); ?>, <?php echo e(/unless); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <ins><?php echo e(compare.name); ?></ins>
        <?php echo e(#if compare.title); ?>

          &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br compare.description); ?>" title="" data-original-title="<?php echo e(compare.title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
          <?php echo e(#unless _last); ?>, <?php echo e(/unless); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <del><?php echo e(compare.name); ?></del>
        <?php echo e(#if compare.title); ?>

          &nbsp;<a href="#" data-toggle="popover" data-placement="right" data-html="true" data-content="<?php echo e(nl2br compare.description); ?>" title="" data-original-title="<?php echo e(compare.title); ?>"><span class="label label-info"><i class="icon icon-info-sign icon-white"></i></span></a>
          <?php echo e(#unless _last); ?>, <?php echo e(/unless); ?>

        <?php echo e(/if); ?>

      <?php echo e(/if); ?>

    <?php echo e(/if); ?>

  <?php echo e(/each_compare_list_field); ?>

</script>

<script id="template-article-compare-param-block" type="text/x-handlebars-template">
  <?php echo e(#if source); ?>

    <?php echo e(#each_compare_keys source.fields compare.fields); ?>

      <?php echo e(#if typeSame); ?>

        <h2><?php echo e(__ source.key); ?></h2>
        <table>
        <thead>
          <tr>
            <th style="width: 30%"><?php echo e(#if ../../_col1); ?><?php echo e(__ ../../_col1); ?><?php echo e(else); ?><?php echo e(__ "Field"); ?><?php echo e(/if); ?></th>
            <?php echo e(#if ../../_hasType); ?><th style="width: 10%"><?php echo e(__ "Type"); ?></th><?php echo e(/if); ?>

            <th style="width: <?php echo e(#if ../../_hasType); ?>60%<?php echo e(else); ?>70%<?php echo e(/if); ?>"><?php echo e(__ "Description"); ?></th>
          </tr>
        </thead>
        <?php echo e(subTemplate "article-compare-param-block-body" source=source.value compare=compare.value _hasType=../../_hasType); ?>

        </table>
      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <h2><ins><?php echo e(__ source.key); ?></ins></h2>
        <table class="ins">
        <thead>
          <tr>
            <th style="width: 30%"><?php echo e(#if ../../_col1); ?><?php echo e(__ ../../_col1); ?><?php echo e(else); ?><?php echo e(__ "Field"); ?><?php echo e(/if); ?></th>
            <?php echo e(#if ../../_hasType); ?><th style="width: 10%"><?php echo e(__ "Type"); ?></th><?php echo e(/if); ?>

            <th style="width: <?php echo e(#if ../../_hasType); ?>60%<?php echo e(else); ?>70%<?php echo e(/if); ?>"><?php echo e(__ "Description"); ?></th>
          </tr>
        </thead>
        <?php echo e(subTemplate "article-compare-param-block-body" source=source.value compare=source.value _hasType=../../_hasType); ?>

        </table>
      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <h2><del><?php echo e(__ compare.key); ?></del></h2>
        <table class="del">
        <thead>
          <tr>
            <th style="width: 30%"><?php echo e(#if ../../_col1); ?><?php echo e(__ ../../_col1); ?><?php echo e(else); ?><?php echo e(__ "Field"); ?><?php echo e(/if); ?></th>
            <?php echo e(#if ../../_hasType); ?><th style="width: 10%"><?php echo e(__ "Type"); ?></th><?php echo e(/if); ?>

            <th style="width: <?php echo e(#if ../../_hasType); ?>60%<?php echo e(else); ?>70%<?php echo e(/if); ?>"><?php echo e(__ "Description"); ?></th>
          </tr>
        </thead>
        <?php echo e(subTemplate "article-compare-param-block-body" source=compare.value compare=compare.value _hasType=../../_hasType); ?>

        </table>
      <?php echo e(/if); ?>

    <?php echo e(/each_compare_keys); ?>


    <ul class="nav nav-tabs nav-tabs-examples">
    <?php echo e(#each_compare_title source.examples compare.examples); ?>


      <?php echo e(#if typeSame); ?>

        <li<?php echo e(#if_eq index compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
          <a href="#<?php echo e(../../section); ?>-compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>"><?php echo e(showDiff source.title compare.title); ?></a>
        </li>
      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <li<?php echo e(#if_eq index compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
          <a href="#<?php echo e(../../section); ?>-compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>"><ins><?php echo e(source.title); ?></ins></a>
        </li>
      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <li<?php echo e(#if_eq index compare=0); ?> class="active"<?php echo e(/if_eq); ?>>
          <a href="#<?php echo e(../../section); ?>-compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>"><del><?php echo e(compare.title); ?></del></a>
        </li>
      <?php echo e(/if); ?>


    <?php echo e(/each_compare_title); ?>

    </ul>

    <div class="tab-content">
    <?php echo e(#each_compare_title source.examples compare.examples); ?>


      <?php echo e(#if typeSame); ?>

        <div class="tab-pane<?php echo e(#if_eq index compare=0); ?> active<?php echo e(/if_eq); ?>" id="<?php echo e(../../section); ?>-compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>">
          <pre class="prettyprint language-<?php echo e(source.type); ?>" data-type="<?php echo e(source.type); ?>"><code><?php echo e(showDiff source.content compare.content); ?></code></pre>
        </div>
      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <div class="tab-pane<?php echo e(#if_eq index compare=0); ?> active<?php echo e(/if_eq); ?>" id="<?php echo e(../../section); ?>-compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>">
          <pre class="prettyprint language-<?php echo e(source.type); ?>" data-type="<?php echo e(source.type); ?>"><code><?php echo e(source.content); ?></code></pre>
        </div>
      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <div class="tab-pane<?php echo e(#if_eq index compare=0); ?> active<?php echo e(/if_eq); ?>" id="<?php echo e(../../section); ?>-compare-examples-<?php echo e(../../article.id); ?>-<?php echo e(index); ?>">
          <pre class="prettyprint language-<?php echo e(source.type); ?>" data-type="<?php echo e(compare.type); ?>"><code><?php echo e(compare.content); ?></code></pre>
        </div>
      <?php echo e(/if); ?>


    <?php echo e(/each_compare_title); ?>

    </div>

  <?php echo e(/if); ?>

</script>

<script id="template-article-compare-param-block-body" type="text/x-handlebars-template">
  <tbody>
    <?php echo e(#each_compare_field source compare); ?>

      <?php echo e(#if typeSame); ?>

        <tr>
          <td class="code">
            <?php echo e(splitFill source.field "." "&nbsp;&nbsp;"); ?>

            <?php echo e(#if source.optional); ?>

              <?php echo e(#if compare.optional); ?> <span class="label label-optional"><?php echo e(__ "optional"); ?></span>
              <?php echo e(else); ?> <span class="label label-optional label-ins"><?php echo e(__ "optional"); ?></span>
              <?php echo e(/if); ?>

            <?php echo e(else); ?>

              <?php echo e(#if compare.optional); ?> <span class="label label-optional label-del"><?php echo e(__ "optional"); ?></span><?php echo e(/if); ?>

            <?php echo e(/if); ?>

          </td>

        <?php echo e(#if source.type); ?>

          <?php echo e(#if compare.type); ?>

          <td><?php echo e(showDiff source.type compare.type); ?></td>
          <?php echo e(else); ?>

          <td><?php echo e(source.type); ?></td>
          <?php echo e(/if); ?>

        <?php echo e(else); ?>

          <?php echo e(#if compare.type); ?>

          <td><?php echo e(compare.type); ?></td>
          <?php echo e(else); ?>

            <?php echo e(#if ../../../../_hasType); ?><td></td><?php echo e(/if); ?>

          <?php echo e(/if); ?>

        <?php echo e(/if); ?>

          <td>
            <?php echo e(showDiff source.description compare.description "nl2br"); ?>

            <?php echo e(#if source.defaultValue); ?><p class="default-value"><?php echo e(__ "Default value:"); ?> <code><?php echo e(showDiff source.defaultValue compare.defaultValue); ?></code><p><?php echo e(/if); ?>

          </td>
        </tr>
      <?php echo e(/if); ?>


      <?php echo e(#if typeIns); ?>

        <tr class="ins">
          <td class="code">
            <?php echo e(splitFill source.field "." "&nbsp;&nbsp;"); ?>

            <?php echo e(#if source.optional); ?> <span class="label label-optional label-ins"><?php echo e(__ "optional"); ?></span><?php echo e(/if); ?>

          </td>

        <?php echo e(#if source.type); ?>

          <td><?php echo e(source.type); ?></td>
        <?php echo e(else); ?>

          <?php echo e(typRowTd); ?>

        <?php echo e(/if); ?>


          <td>
            <?php echo e(nl2br source.description); ?>

            <?php echo e(#if source.defaultValue); ?><p class="default-value"><?php echo e(__ "Default value:"); ?> <code><?php echo e(source.defaultValue); ?></code><p><?php echo e(/if); ?>

          </td>
        </tr>
      <?php echo e(/if); ?>


      <?php echo e(#if typeDel); ?>

        <tr class="del">
          <td class="code">
            <?php echo e(splitFill compare.field "." "&nbsp;&nbsp;"); ?>

            <?php echo e(#if compare.optional); ?> <span class="label label-optional label-del"><?php echo e(__ "optional"); ?></span><?php echo e(/if); ?>

          </td>

        <?php echo e(#if compare.type); ?>

          <td><?php echo e(compare.type); ?></td>
        <?php echo e(else); ?>

          <?php echo e(typRowTd); ?>

        <?php echo e(/if); ?>


          <td>
            <?php echo e(nl2br compare.description); ?>

            <?php echo e(#if compare.defaultValue); ?><p class="default-value"><?php echo e(__ "Default value:"); ?> <code><?php echo e(compare.defaultValue); ?></code><p><?php echo e(/if); ?>

          </td>
        </tr>
      <?php echo e(/if); ?>


    <?php echo e(/each_compare_field); ?>

  </tbody>
</script>

<div class="container-fluid">
  <div class="row-fluid">
    <div id="sidenav" class="span2"></div>
    <div id="content">
      <div id="project"></div>
      <div id="header"></div>
      <div id="sections"></div>
      <div id="footer"></div>
      <div id="generator"></div>
    </div>
  </div>
</div>

<div id="loader">
  <div class="spinner">
    <div class="spinner-container container1">
      <div class="circle1"></div><div class="circle2"></div><div class="circle3"></div><div class="circle4"></div>
    </div>
    <div class="spinner-container container2">
      <div class="circle1"></div><div class="circle2"></div><div class="circle3"></div><div class="circle4"></div>
    </div>
    <div class="spinner-container container3">
      <div class="circle1"></div><div class="circle2"></div><div class="circle3"></div><div class="circle4"></div>
    </div>
    <p>Loading...</p>
  </div>
</div>

<script data-main="main.js" src="vendor/require.min.js"></script>
</body>
</html>
