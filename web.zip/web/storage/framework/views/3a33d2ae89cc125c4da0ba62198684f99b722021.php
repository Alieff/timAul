<?php $__env->startSection('content'); ?>
<div class="row container-x well">
    <form method="post" action="<?php echo e(URL::route('explore.request', array('id' => $offset))); ?>" class="form-horizontal" role="form" target="response">
    <fieldset>
    <legend>
        <span style="text-transform:uppercase;"><?php echo e($data['type']); ?></span> : <?php echo e(array_get($data, 'title', 'Undefined')); ?>

    </legend>
        <div class="form-group">
            <div class="col-sm-12">
                <input type="text" name="endpoint" value="<?php echo e(Input::get('endpoint', Config::get('explore.endpoint').$data['url'])); ?>" class="form-control" placeholder="Api Enpoint URL">
            </div>
        </div>

        <div class="availables">
            <?php foreach($data['parameter']['fields']['Parameter'] as $k => $param): ?>
            <div class="form-group">
                <div class="col-sm-3">
                    <input type="text" name="fields[]" value="<?php echo e(Input::get('fields.'.$k, $param['field'])); ?>" class="form-control">
                </div>
                <div class="col-sm-8">
                    <input type="text" name="values[]" value="<?php echo e(Input::get('values.'.$k, array_get($param, 'value'))); ?>" class="form-control" placeholder="<?php echo e(strip_tags($param['description'])); ?>">
                </div>
                <div class="col-sm-1">
                    <a href="javascript:void(0)" class="remove-node" tabindex="-1"><span class="glyphicon glyphicon-minus"></span></a>
                </div>
            </div>
            <?php endforeach; ?>
            <div class="form-group">
                <div class="col-sm-3">
                    <input type="text" name="fields[]" class="form-control" placeholder="key">
                </div>
                <div class="col-sm-8">
                    <input type="text" name="values[]" class="form-control" placeholder="value">
                </div>
                <div class="col-sm-1">
                    <a href="javascript:void(0)" class="remove-node" tabindex="-1"><span class="glyphicon glyphicon-minus"></span></a>
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button type="reset" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-primary">Request</button>
            </div>
        </div>
    </fieldset>
    </form>
</div>

<div class="row response">
    <iframe name="response" id="iframe1" src="<?php echo e(URL::route('explore.request', array('id' => $offset))); ?>" width="100%" marginheight="0" frameborder="0" onLoad="autoResize('iframe1');"></iframe>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(Config::get('explore.template'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>