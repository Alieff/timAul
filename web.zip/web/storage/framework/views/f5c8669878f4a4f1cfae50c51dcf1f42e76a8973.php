<div class="row container">
        <div class="col-lg-3 col-lg-offset-2 col-md-3 col-md-offset-2 col-xs-4">
        <span style="color: #fff" id="copyright" style="">
        &copy; Copyright - TimAul 2016
        </span>
        </div>
        <!--div class="col-lg-3 col-lg-offset-2 col-md-3 col-md-offset-2 col-xs-3 col-xs-offset-1"-->
        <span style="float: right" >
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-google-plus"></i></a>
            <a href="#"><i class="fa fa-skype"></i></a>
        </span>
        <!--/div--      ><!--End container-->
</div>